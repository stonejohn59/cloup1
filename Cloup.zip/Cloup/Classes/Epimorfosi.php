<?php
class Epimorfosi {
    var $ekpaideyomenos;
    var $eidikeysh;
    
   function __construct(){
       $this->ekpaideyomenos = -1;
       $this->eidikeysh = -1;
   } 
   
  function setDb() {
        $DB = new Database();
        $DB->setEpimorfosi($this);
    }
    
     function getDb() {
        $DB = new Database();
        $DB->getEpimorfosi($this);
    }
}//Class Epimorfosi ends here
