<?php
class Tekno {
    var $AMKA_teknou    ;
    
    function __construct(){
        $this->AMKA_teknou    = -1;
    }
}//Class Tekno ends here