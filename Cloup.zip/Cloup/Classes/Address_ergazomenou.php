<?php
class Address_ergazomenou {
    var $odos;
    var $arithmos;
    var $polh;
    var $zip_code;
    var $kwd_ergazomenou_adr;
    
    function __construct(){
        $this->odos = "";
        $this->arithmos = "";
        $this->polh = "";
        $this->zip_code = -1;
        $this->kwd_ergazomenou_adr = -1;    
    }
}//Class Address_ergazomenou ends here
