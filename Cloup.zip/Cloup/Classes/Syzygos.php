<?php
class Syzygos {
    var $AMKA_syzygou   ;
    
    function __construct(){
        $this->AMKA_syzygou   = -1;
    }
}//Class Syzygos ends here