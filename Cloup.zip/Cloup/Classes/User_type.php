<?php
class User_type{
    var $user_type_id ;
    var $user_type_name;
    
    function __construct(){
        $this->user_type_id = -1;
        $this->user_type_name = ""; 
    }
}//Class User_type ends here