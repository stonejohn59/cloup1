<?php

session_start();

require_once '../../Classes/Ergazomenos.php';
require_once '../../Classes/Database.php';

if ((isset($_POST['editergazomenosid'])) && (!isset($_POST['editergazomenosid2']))) {
    $editergazomenos=new Ergazomenos();
    $editergazomenos->kwd_ergazomenou=$_POST['editergazomenosid'];
    $editergazomenos->getDb();
    
    ?>
    <form action="" method="post">
        <div id="SearchPart" class="col-lg-4">
            <h3>Επεξεργασία Στοιχείων Εργαζομένου</h3>
            


            <div class="form-group">
                <label for="editergazomenosid2">Κωδικός Εργαζομένου </label>
                <input type="text" id="editergazomenosid2" name="editergazomenosid2" value="<?php echo $_POST['editergazomenosid']; ?>" required class="form-control">
            </div>  
            <div class="form-group">
                <label for="Onoma_Ergazom">Όνομα Εργαζομένου</label>
                <input type="text" id="Onoma_Ergazom" name="Onoma_Ergazom" value="<?php echo $editergazomenos->Onoma_Ergazom; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="Eponymo_ergazom">Επώνυμο Εργαζομένου</label>
                <input type="text" id="Eponymo_ergazom" name="Eponymo_ergazom" value="<?php echo $editergazomenos->Eponymo_ergazom; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="AFM_Ergaz">ΑΦΜ Εργαζομένου</label>
                <input type="text" id="AFM_Ergaz" name="AFM_Ergaz" value="<?php echo $editergazomenos->AFM_Ergaz; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="Fyllo_Ergaz">Φύλλο Εργαζομένου</label>
                <input type="text" id="Fyllo_Ergaz" name="Fyllo_Ergaz" value="<?php echo $editergazomenos->Fyllo_Ergaz; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="Tel_Ergaz">Τηλέφωνο Εργαζομένου</label>
                <input type="text" id="Tel_Ergaz" name="Tel_Ergaz" value="<?php echo $editergazomenos->Tel_Ergaz; ?>"  class="form-control" required>
            </div>


            <button style="float: left" type="submit" name="EditErgazomenos" id="EditErgazomenos" value="Ενημέρωση" class="btn btn-info "><span class="glyphicon glyphicon-retweet"></span> Ενημέρωση Εργαζομένου</button>
            <button style="float: left ; color: #ff6666" type="button" name="cancel" id="cancel" value="Ακύρωση" onclick="window.location = 'Index.php';" class="btn btn-info "><span class="glyphicon glyphicon-remove-sign"></span> Ακύρωση</button>

    </form>
    </div>

    <?php
} else {
    
    $editergazomenosfinal= new Ergazomenos();
    $editergazomenosfinal->kwd_ergazomenou=$_POST['editergazomenosid2'];
    $editergazomenosfinal->Onoma_Ergazom=$_POST['Onoma_Ergazom'];
    $editergazomenosfinal->Eponymo_ergazom=$_POST['Eponymo_ergazom'];
    $editergazomenosfinal->AFM_Ergaz=$_POST['AFM_Ergaz'];
    $editergazomenosfinal->Fyllo_Ergaz=$_POST['Fyllo_Ergaz'];
    $editergazomenosfinal->Tel_Ergaz=$_POST['Tel_Ergaz'];
    $editergazomenosfinal->updateDb();
    
}

