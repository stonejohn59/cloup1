<?php
session_start();
  require_once '../../Classes/Ergazomenos.php';
  require_once '../../Classes/Database.php';
 
$ergazomenos= new Ergazomenos();
$ergazomenos->kwd_ergazomenou=$_POST['delergazomenosid'];


if (!isset($_POST['delbutton'])){
    
    echo 'Είστε σίγουρος για την διαγραφή';
    $delcode=$ergazomenos->kwd_ergazomenou;
    ?>
<form action="" method="post">
    <input type="hidden" name="delcode" value="<?php echo $delcode; ?>" >
<button style="float: left" type="submit" name="delbutton" id="delbutton" onclick="return confirm('Επιβεβαιώστε την διαγραφή')" value="Διαγραφή" class="btn btn-info "><span class="glyphicon glyphicon-trash"></span> Διαγραφή Εργαζομένου</button>
</form>     
    
<?php
}

else { //Σου πατάω το κουμπί επιβεβαίωσης οπότε διέγραψέ το.
$delcode=$_POST['delcode'];
$DB=new Database();
$DB->connect();
$sql = "DELETE FROM `$ergazomenos` WHERE `kwd_ergazomenou`= ?";
        $DB->execute($sql, [$delcode]);
        echo 'Επιτυχής Διαγραφή';
}