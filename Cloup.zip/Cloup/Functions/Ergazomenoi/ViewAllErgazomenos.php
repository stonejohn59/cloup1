<h2>Προβολή όλων των Έργαζομένων</h2>
<?php
session_start();
  require_once '../../Classes/Ergazomenos.php';
  require_once '../../Classes/Database.php';
?>

<div><table class="table table-responsive table-bordered table-condensed"
            style="
            border-radius: 10px;
            padding-top: 5px;
            padding-left: 5px;
            padding-right: 5px;
            padding-bottom: 5px;
            max-width: available;
            margin: 0px;
            background-color: whitesmoke;
            ">
        <thead>
            <tr style="background-color:   #6699ff">

                <th style=white-space:nowrap">Κωδικός</th>
                <th>Όνομα</th>
                <th>Επώνυμο</th>
                <th>ΑΦΜ</th>
                <th>Φύλλο</th>
                <th>Τηλέφωνο</th> 
              
                <th style="width: 250px">Λειτουργίες</th>

            </tr>
        </thead>
        <tbody>
            <tr style="">
                <?php
                $DB = new Database();
                $DB->connect();
                $sql = "SELECT `kwd_ergazomenou`, `Onoma_Ergazom`, `Eponymo_ergazom`, `Fyllo_Ergaz`, `AFM_Ergaz`, `Tel_Ergaz`  FROM `Ergazomenos` where 1 ";
                $res = $DB->execute($sql, []);
                while ($row = $res->fetch()) {
                    echo "<td>" . $row['kwd_ergazomenou'] . "</td>";
                    echo "<td>" . $row['Onoma_Ergazom'] . "</td>";
                    echo "<td>" . $row['Eponymo_ergazom'] . "</td>";
                    echo "<td>" . $row['Fyllo_Ergaz'] . "</td>";
                    echo "<td>" . $row['AFM_Ergaz'] . "</td>";
                    echo "<td>" . $row['Tel_Ergaz'] . "</td>";    
                    
                    ?>
                    <td class="">
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Ergazomenoi/ViewErgazomenos.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="viewergazomenosid" value="<?php echo $row['kwd_ergazomenou']; ?>" readonly>
                            <button type="submit" title="Προβολή Έργαζόμενου" style="width:120px; height:20px; background-color:blue;" class="btn-large">
                                <i>Προβολή</i></button>
                        </form>
                        
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Ergazomenoi/DeleteErgazomenos.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="delergazomenosid" value="<?php echo $row['kwd_ergazomenou'];?>" readonly>
                            <button type="submit" title="Διαγραφή Έργαζόμενου" style="width:120px; height:20px; background-color:red;" class="btn-large">
                                <i>Διαγραφή</i></button>
                        </form>
                        
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Ergazomenoi/EditErgazomenos.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="editergazomenosid" value="<?php echo $row['kwd_ergazomenou'];?>" readonly>
                            <button type="submit" title="Τροποποίηση Έργαζόμενου" style="width:120px; height:20px; background-color:green;" class="btn-large">
                                <i>Τροποποίηση</i></button>
                        </form>

                    </td>

                    <?php
                    echo "</tr>";
                }//Τέλος εκτύπωσης γραμμής
                ?>
                <?php
                echo "</tbody></table></div>";
