<?php
session_start();
  require_once '../../Classes/Ergazomenos.php';
  require_once '../../Classes/Database.php';
  require_once '../../Classes/Tekno.php';
  require_once '../../Classes/Syzygos.php';
  require_once '../../Classes/Eksartomenos.php';
  
 
  $DB = new Database();
  $DB->connect();
  // Έλεγχος για την ύπαρξη συζήγου
  $sql ="SELECT AMKA_eksart from eksartomenos"
          . " join ergazomenos on ergazomenos.kwd_ergazomenou = eksartomenos.kod_prostati"
          . " join syzygos on syzygos.AMKA_syzygou = eksartomenos.AMKA_eksart"
          . " WHERE ergazomenos.kwd_ergazomenou =?";
  $res = $DB->execute($sql, [$ergazomenos->kwd_ergazomenou]);
  if ($res->rowCount() >0) { // Άν φέρει αποτέλεσμα είναι παντρεμένος
      echo "Ο εργαζόμενος είναι παντρεμένος";
  } else { 
      echo "Ο εργαζόμενος δεν είναι παντρεμένος";
  }
  echo '</br>';
  
  
  $DB = new Database();
  $DB->connect();
  $sql = "SELECT AMKA_eksart from eksartomenos"   // Έλεγχος για το αν υπάρχουν παιδια
          ." join ergazomenos on ergazomenos.kwd_ergazomenou = eksartomenos.kod_prostati"
          ." join tekno on tekno.AMKA_teknou = eksartomenos.AMKA_eksart"
          ." WHERE ergazomenos.kwd_ergazomenou =?";
  $res = $DB->execute($sql, [$ergazomenos->kwd_ergazomenou]);
  if ($res->rowCount() >1) { // Άν είναι >1 έχει παιδιά
      echo "Ο εργαζόμενος έχει" .$res->rowCount(). "παιδιά";//Θα μας δείξει τον αριθμό παιδιών
  } else if {$res->rowCount() >0 { //Άν είναι >0 έχει παιδί
      echo "Ο εργαζόμενος έχει". .$res->rowCount()."παιδί";
  } else {
      echo "ο εργαζόμενος δεν έχει παιδιά";  
      }
 
  
  
  
  
  


