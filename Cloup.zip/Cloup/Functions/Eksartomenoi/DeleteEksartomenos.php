<?php
session_start();
  require_once '../../Classes/Eksartomenos.php';
  require_once '../../Classes/Database.php';
 
$Eksartomenos= new Eksartomenos();
$Eksartomenos  ->AMKA_eksart=$_POST['deleksartomenosid'];


if (!isset($_POST['delbutton'])){
    
    echo 'Είστε σίγουρος για την διαγραφή';
    $delcode=$Eksartomenos-> AMKA_eksart;
    ?>
<form action="" method="post">
    <input type="hidden" name="delcode" value="<?php echo $delcode; ?>" >
<button style="float: left" type="submit" name="delbutton" id="delbutton" onclick="return confirm('Επιβεβαιώστε την διαγραφή')" value="Διαγραφή" class="btn btn-info "><span class="glyphicon glyphicon-trash"></span> Διαγραφή Εξαρτόμενου</button>
</form>     
    
<?php
}

else { //Σου πατάω το κουμπί επιβεβαίωσης οπότε διέγραψέ το.
$delcode=$_POST['delcode'];
$DB=new Database();
$DB->connect();
$sql = "DELETE FROM `eksartomenos` WHERE  `AMKA_eksart`= ?";
        $DB->execute($sql, [$delcode]);
        echo 'Επιτυχής Διαγραφή';
}