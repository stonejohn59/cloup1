<?php
session_start();

require_once '../../Classes/Eksartomenos.php';
require_once '../../Classes/Database.php';
require_once '../../Classes/Ergazomenos.php';

if (!isset($_POST['search'])) { ?>

<h1 class="form-header">Αναζήτηση Εξαρτόμενου</h1> 
    <form action="" method="post"> 
        <div class="form-group">
                <label for="AMKA_eksart">ΑΜΚΑ Εξαρτόμενου </label>
                <input type="text" id="odhgos" name="AMKA_eksart" class="form-control">
            </div>  
            <div class="form-group">
                <label for="Onoma_eksart">Όνομα Εξαρτόμενου </label>
                <input type="text" id="Onoma_eksart" name="Onoma_eksart" class="form-control">
            </div>  
        <div class="form-group">
                <label for="Eponymo_eksart">Επώνυμο Εξαρτόμενου </label>
                <input type="text" id="Eponymo_eksart" name="Eponymo_eksart" class="form-control">
            </div> 
        <div class="form-group">
                <label for="DOB_eksart">Ημερομηνία Γέννησης </label>
                <input type="date" id="DOB_eksart" name="DOB_eksart" class="form-control">
            </div>
        <div class="form-group">
                <label for="Fylo_eksart">Φύλλο Εξαρτόμενου </label>
                <select type="text" id="Fylo_eksart" name="Fylo_eksart" class="form-control">
                     <option value =null>-</option>
                    <option value ="F">Θυλη</option>
                    <option value ="M">Αρρεν</option>
                </select>
            </div> 
        <div class="form-group">
                <label for="kod_prostati">Κωδικός Προστάτη </label>
                <input type="text" id="kod_prostati" name="kod_prostati" class="form-control">
            </div>  
        
        
            <div class="clear-float"></div>
            <button style="float: left" type="submit" name="search" id="search" value="Αναζήτηση" class="btn btn-info "><span class="fa-search "></span> Αναζήτηση Εξαρτόμενου</button>
            <button style="float: left;color: #ff6666" type="button" name="cancel" id="cancel" value="Ακύρωση" onclick="window.location = 'ιndex.php';" class="btn btn-info "><span class="fa-backward"></span> Ακύρωση</button>
            <br><br>
        </form>
    
 <?php   
}
else {

    echo "<h3>Εξαρτόμενος:</h3>";
    $DB = new Database();
    $DB->connect();
    $sql ="SELECT `AMKA_eksart`, `Onoma_eksart`, `Eponymo_eksart`, `DOB_eksart` , `Fylo_eksart`, `kod_prostati` FROM `Eksartomenos`";
    $w = "where ?";

    $i = 0;
    $a = [];
    $a[$i++] = "1";


   if ($_POST['AMKA_eksart'] !== "") {
        $w = $w . " and AMKA_eksart = ? ";
        $a[$i++] =$_POST['AMKA_eksart'];
    }
   if ($_POST['Onoma_eksart'] !== "") {
        $w = $w . " and Onoma_eksart like ? ";
        $a[$i++] = "%" . $_POST['Onoma_eksart'] . "%";
    }
   if ($_POST['Eponymo_eksart'] !== "") {
        $w = $w . " and Eponymo_eksart like ? ";
        $a[$i++] = "%" . $_POST['Eponymo_eksart'] . "%";
    }
    if ($_POST['DOB_eksart'] !== "") {
        $w = $w . " and DOB_eksart = ? ";
        $a[$i++] = $_POST['DOB_eksart'];
    }
    if ($_POST['Fylo_eksart'] !== "null") {
        $w = $w . " and Fylo_eksart = ? ";
        $a[$i++] = $_POST['Fylo_eksart'];
    }
    if ($_POST['kod_prostati'] !== "") {
        $w = $w . " and kod_prostati = ? ";
        $a[$i++] = $_POST['kod_prostati'];
    }

    ?>
    <div><table class="table table-bordered table-hover table-responsive" style="width: available;background-color: cyan">

            <thead>
                <tr style="background-color: darkcyan">

                    <th>ΑΜΚΑ Εξαρτόμενου</th>
                    <th>Όνομα Εξαρτόμενου</th>
                    <th>Επώνυμο Εξαρτόμενου</th>
                    <th>Ημερμηνία Γέννησης</th>
                    <th>Φύλλο Εξαρτόμενου</th>
                    <th>Κωδικός Προστάτη</th> 
                    <th>Λειτουργίες</th> 
                </tr>
            </thead>
            <tbody>
                <tr>
                    <?php
                    $res = $DB->execute($sql . $w, $a);
                    
                    //-------------Μέτρηση αποτελεσμάτων εγγραφών---------//

                    if ($res->rowCount() == 1) {

                        echo "<h4>Βρέθηκε " . $res->rowCount() . " εγγραφή με τα κριτήρια που δώσατε! </h4>";
                    } else if ($res->rowCount() == 0) {

                        echo "<h4>Δεν βρέθηκαν εγγραφές με τα κριτήρια που δώσατε! </h4>";
                    } else {
                        echo "<h4>Βρέθηκαν " . $res->rowCount() . " εγγραφές με τα κριτήρια που δώσατε! </h4>";
                    }

                    while ($row = $res->fetch()) {

                        $EksartomenosSearch = new Eksartomenos();
                        $EksartomenosSearch->kod_prostati = $row['kod_prostati'];
                        $EksartomenosSearch->getDb();
                        
                        
                       
                       
                        echo "<td>" . $EksartomenosSearch->AMKA_eksart . "</td>";
                        echo "<td>" . $EksartomenosSearch->Onoma_eksart . "</td>";
                        echo "<td>" . $EksartomenosSearch->Eponymo_eksart . "</td>";
                        echo "<td>" . $EksartomenosSearch->DOB_eksart . "</td>";
                        echo "<td>" . $EksartomenosSearch->Fylo_eksart . "</td>";
                        echo "<td>" . $EksartomenosSearch->kod_prostati . "</td>";
                        ?>

                        <td class="">
                            <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Eksartomenoi/ViewEksartomenos.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="vieweksartomenosid" value="<?php echo $EksartomenosSearch->AMKA_eksart; ?>" readonly>
                            <button type="submit" title="Προβολή Εξαρτόμενου" style="width:120px; height:40px; background-color:blue;" class="btn-large">
                                <i>Προβολή </i></button>
                        </form>
                            
                            <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Eksartomenoi/EditEksartomenos.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="editeksartomenosid" value="<?php echo $EksartomenosSearch->AMKA_eksart; ?>" readonly>
                            <button type="submit" title="Επεξεργασία Εξαρτόμενου" style="width:120px; height:40px; background-color:greenyellow;" class="btn-large">
                                <i>Επεξεργασία </i></button>
                        </form>
                            
                            
                            
                            
                            
                        <?php
                        if ($_SESSION['user_type_ergazom']==1) { ?>
                            <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Eksartomenoi/DeleteEksartomenos.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="deleksartomenosid" value="<?php echo $EksartomenosSearch->AMKA_eksart;?>" readonly>
                            <button type="submit" title="Διαγραφή Εξαρτόμενου" style="width:120px; height:40px; background-color:red;" class="btn-large">
                                <i>Διαγραφή </i></button>
                        </form> <?php } ?>

                    </td>

                        <?php
                        echo "</tr>";
                    }
                    ?>

                    <?php
                    echo "</tbody></table></div>";
                }



