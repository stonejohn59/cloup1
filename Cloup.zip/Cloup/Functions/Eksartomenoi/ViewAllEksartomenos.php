<h2>Προβολή όλων των Εξαρτόμενων</h2>
<?php
session_start();
  require_once '../../Classes/Eksartomenos.php';
  require_once '../../Classes/Database.php';
?>

<div><table class="table table-responsive table-bordered table-condensed"
            style="
            border-radius: 10px;
            padding-top: 5px;
            padding-left: 5px;
            padding-right: 5px;
            padding-bottom: 5px;
            max-width: available;
            margin: 0px;
            background-color: whitesmoke;
            ">
        <thead>
            <tr style="background-color:   #6699ff">

                <th style=white-space:nowrap">Κωδικός Προστάτη</th>
                <th>Όνομα</th>
                <th>Επώνυμο</th>
                <th>Ημ/νία Γέννησης</th> 
                <th>ΑΜΚΑ</th>
                <th>Φύλλο Εξαρτόμενου</th>
              
                <th style="width: 250px">Λειτουργίες</th>

            </tr>
        </thead>
        <tbody>
            <tr style="">
                <?php
                $DB = new Database();
                $DB->connect();
                $res = $DB->execute("SELECT `kod_prostati`, `Onoma_eksart`, `Eponymo_eksart`, `DOB_eksart`, `Fylo_eksart`, `AMKA_eksart` "
                        ."FROM `eksartomenos` where `kod_prostati` !=1 ", []);
                while ($row = $res->fetch()) {
                    echo "<td>" . $row['kod_prostati'] . "</td>";
                    echo "<td>" . $row['Onoma_eksart'] . "</td>";
                    echo "<td>" . $row['Eponymo_eksart'] . "</td>";
                    echo "<td>" . $row['DOB_eksart'] . "</td>";
                    echo "<td>" . $row['Fylo_eksart'] . "</td>";
                    echo "<td>" . $row['AMKA_eksart'] . "</td>";
                    
                    ?>
                    <td class="">
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Eksartomenoi/ViewEksartomenos.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="vieweksartomenosid" value="<?php echo $row['$kod_prostati']; ?>" readonly>
                            <button type="submit" title="Προβολή Εξαρτόμενου" style="width:120px; height:20px; background-color:blue;" class="btn-large">
                                <i>Προβολή </i></button>
                        </form>
                        
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Eksartomenoi/DeleteEksartomenos.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="deleksartomenosid" value="<?php echo $row['$kod_prostati'];?>" readonly>
                            <button type="submit" title="Διαγραφή Εξαρτόμενου" style="width:120px; height:20px; background-color:red;" class="btn-large">
                                <i>Διαγραφή </i></button>
                        </form>
                        
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Eksartomenoi/EditEksartomenos.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="editsartomenosid" value="<?php echo $row['$kod_prostati'];?>" readonly>
                            <button type="submit" title="Τροποποίηση Εξαρτόμενου" style="width:120px; height:20px; background-color:green;" class="btn-large">
                                <i>Τροποποίηση </i></button>
                        </form>
                        
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Eksartomenoi/ViewEksartomenos.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="viewergazomenosid" value="<?php echo $row['$kod_prostati'];?>" readonly>
                            <button type="submit" title="Προβολή Προστάτη" style="width:120px; height:20px; background-color:coral;" class="btn-large">
                                <i>Προβολή Προστάτη </i></button>
                        </form>

                    </td>

                    <?php
                    echo "</tr>";
                }//Τέλος εκτύπωσης γραμμής
                ?>
                <?php
                echo "</tbody></table></div>";



                