<?php
session_start();
  require_once '../../Classes/Eksartomenos.php';
  require_once '../../Classes/Database.php';
  require_once '../..Classes/Ergazomenos.php';
  

$Eksartomenos= new Eksartomenos();
$Eksartomenos->kod_prostati=$_POST['vieweksartomenosid'];
$Eksartomenos->getDb();

$ergazomenos= new Ergazomenos();
$ergazomenos->kwd_ergazomenou=$_POST['viewergazomenosid'];
$ergazomenos->getDb();

echo "Προβολή του εξαρτόμενου:".$Eksartomenos->Onoma_eksart;
echo '</br>';
echo "Προβολή του Προστάτη:".$ergazomenos->kod_prostati;