<?php


session_start();

require_once '../../Classes/Eksartomenos.php';
require_once '../../Classes/Database.php';

if ((isset($_POST['editeksartomenosid'])) && (!isset($_POST['editeksartomenosid2']))) {
    $editeksartomenos=new Eksartomenos();
    $editeksartomenos->AMKA_eksart=$_POST['editeksartomenosid'];
    $editeksartomenos->getDb();
    
    ?>
    <form action="" method="post">
        <div id="SearchPart" class="col-lg-4">
            <h3>Επεξεργασία Στοιχείων Εξαρτόμενου</h3>
            <input type="text" name="paliosEksartomenosCode" value="<?php echo $_POST['editeksartomenosid']; ?>" >


            <div class="form-group">
                <label for="editeksartomenosid2">ΑΜΚΑ Εξαρτόμενου</label>
                <input type="text" id="editeksartomenosid2" name="editeksartomenosid2" value="<?php echo $_POST['editeksartomenosid2']; ?>" required class="form-control">
            </div>  
            <div class="form-group">
                <label for="$Onoma_eksart">Όνομα Εξαρτόμενου</label>
                <input type="text" id="Onoma_eksart" name="$Onoma_eksart" value="<?php echo $editeksartomenos->$Onoma_eksart; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="Eponymo_eksart">Επώνυμο Εξαρτόμενου</label>
                <input type="text" id="Eponymo_eksart" name="Eponymo_eksart" value="<?php echo $editeksartomenos->Eponymo_eksart; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="DOB_eksart">Ημερμηνία Γέννησης</label>
                <input type="date" id="DOB_eksart" name="DOB_eksart" value="<?php echo $editeksartomenos->DOB_eksart; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="Fylo_eksart">Φύλλο Εξαρτόμενου</label>
                <input type="text" id="Fylo_eksart" name="Fylo_eksart" value="<?php echo $editeksartomenos->Fylo_eksart; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="kod_prostati">Κωδικός Προστάτη</label>
                <input type="text" id="kod_prostati" name="kod_prostati" value="<?php echo $editeksartomenos->kod_prostati; ?>"  class="form-control" required>
            </div>


            <button style="float: left" type="submit" name="EditOxhma" id="editeksartomenos" value="Ενημέρωση" class="btn btn-info "><span class="glyphicon glyphicon-retweet"></span> Ενημέρωση Εξαρτόμενου</button>
            <button style="float: left ; color: #ff6666" type="button" name="cancel" id="cancel" value="Ακύρωση" onclick="window.location = 'Index.php';" class="btn btn-info "><span class="glyphicon glyphicon-remove-sign"></span> Ακύρωση</button>

    </form>
    </div>

    <?php
} else {
    
    $editeksartomenosfinal= new Eksartomenos();
    $editeksartomenosfinal->AMKA_eksart=$_POST['editeksartomenosid2'];
    $editeksartomenosfinal->Onoma_eksart=$_POST['Onoma_eksart'];
    $editeksartomenosfinal->Eponymo_eksart=$_POST['Eponymo_eksart'];
    $editeksartomenosfinal->DOB_eksart=$_POST['DOB_eksart'];
    $editeksartomenosfinal->Fylo_eksart=$_POST['Fylo_eksart'];
    $editeksartomenosfinal->kod_prostati=$_POST['kod_prostati'];
    $editeksartomenosfinal->updateDb();
    
}