<?php


session_start();

require_once '../../Classes/Oxhma.php';
require_once '../../Classes/Database.php';

if ((isset($_POST['editoxhmaid'])) && (!isset($_POST['editoxhma2']))) {
    $editoxhma=new Oxhma();
    $editoxhma->odhgos=$_POST['editoxhmaid'];
    $editoxhma->getDb();
    
    ?>
    <form action="" method="post">
        <div id="SearchPart" class="col-lg-4">
            <h3>Επεξεργασία Στοιχείων Οχήματος</h3>
            <input type="text" name="paliosOxhmaCode" value="<?php echo $_POST['editoxhmaid']; ?>" >


            <div class="form-group">
                <label for="editoxhma2">Κωδικός Οχήματος</label>
                <input type="text" id="editoxhma2" name="editoxhma2" value="<?php echo $_POST['editoxhmaid']; ?>" required class="form-control">
            </div>  
            <div class="form-group">
                <label for="marka_oxhm">Μάρκα Οχήματος</label>
                <input type="text" id="marka_oxhm" name="marka_oxhm" value="<?php echo $editoxhma->marka_oxhm; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="montelo_oxhm">Μοντέλο Οχήματος</label>
                <input type="text" id="montelo_oxhm" name="montelo_oxhm" value="<?php echo $editoxhma->montelo_oxhm; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="ar_kykloforias">Αριθμός Κυκλοφορίας</label>
                <input type="text" id="ar_kykloforias" name="ar_kykloforias" value="<?php echo $editoxhma->ar_kykloforias; ?>"  class="form-control" required>
            </div>


            <button style="float: left" type="submit" name="EditOxhma" id="EditOxhma" value="Ενημέρωση" class="btn btn-info "><span class="glyphicon glyphicon-retweet"></span> Ενημέρωση Οχήματος</button>
            <button style="float: left ; color: #ff6666" type="button" name="cancel" id="cancel" value="Ακύρωση" onclick="window.location = 'Index.php';" class="btn btn-info "><span class="glyphicon glyphicon-remove-sign"></span> Ακύρωση</button>

    </form>
    </div>

    <?php
} else {
    
    $editoximafinal= new Oxhma();
    $editoximafinal->odhgos=$_POST['editoxhma2'];
    $editoximafinal->marka_oxhm=$_POST['marka_oxhm'];
    $editoximafinal->montelo_oxhm=$_POST['montelo_oxhm'];
    $editoximafinal->ar_kykloforias=$_POST['ar_kykloforias'];
    $editoximafinal->updateDb();
    
}