<?php
session_start();
  require_once '../../Classes/Oxhma.php';
  require_once '../../Classes/Database.php';

$Oxhma= new Oxhma();
$Oxhma->odhgos=$_POST['viewoxhmaid'];
$Oxhma->getDb();

echo "Προβολή του οχήματος με κωδικό:".$Oxhma->odhgos;
echo '</br>';
echo "Αριθμός κυκλοφορίας του οχήματος:".$Oxhma->ar_kykloforias;

