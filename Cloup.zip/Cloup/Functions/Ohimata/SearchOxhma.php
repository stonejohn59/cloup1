<?php
session_start();

require_once '../../Classes/Oxhma.php';
require_once '../../Classes/Database.php';
require_once '../../Classes/Ergazomenos.php';

if (!isset($_POST['search'])) { ?>

<h1 class="form-header">Αναζήτηση Οχήματος</h1> 
    <form action="" method="post"> 
        <div class="form-group">
                <label for="odhgos">Κωδικός Οχήματος </label>
                <input type="text" id="odhgos" name="odhgos" class="form-control">
            </div>  
            <div class="form-group">
                <label for="marka_oxhm">Μάρκα Οχήματος</label>
                <input type="text" id="marka_oxhm" name="marka_oxhm" class="form-control">
            </div>  
        <div class="form-group">
                <label for="montelo_oxhm">Μοντέλο Οχήματος </label>
                <input type="text" id="montelo_oxhm" name="montelo_oxhm" class="form-control">
            </div> 
        <div class="form-group">
                <label for="ar_kykloforias">Αριθμός Κυκλοφορίας </label>
                <input type="text" id="ar_kykloforias" name="ar_kykloforias" class="form-control">
            </div>  
        
        
            <div class="clear-float"></div>
            <button style="float: left" type="submit" name="search" id="search" value="Αναζήτηση" class="btn btn-info "><span class="fa-search "></span> Αναζήτηση Οχήματος</button>
            <button style="float: left;color: #ff6666" type="button" name="cancel" id="cancel" value="Ακύρωση" onclick="window.location = 'ιndex.php';" class="btn btn-info "><span class="fa-backward"></span> Ακύρωση</button>
            <br><br>
        </form>
    
 <?php   
}
else {

    echo "<h3>Όχημα:</h3>";
    $DB = new Database();
    $DB->connect();
    $sql ="SELECT `odhgos`, `marka_oxhm`, `montelo_oxhm`, `ar_kykloforias` FROM `Oxhma`";
    $w = "where ?";

    $i = 0;
    $a = [];
    $a[$i++] = "1";


   if ($_POST['odhgos'] !== "") {
        $w = $w . " and odhgos = ? ";
        $a[$i++] = $_POST['odhgos'];
    }

    if ($_POST['marka_oxhm'] !== "") {
        $w = $w . " and marka_oxhm LIKE ? ";
        $a[$i++] ="%" . $_POST['marka_oxhm']. "%" ;
    }
   
    if ($_POST['montelo_oxhm'] !== "") {
        $w = $w . " and montelo_oxhm = ? ";
        $a[$i++] = $_POST['montelo_oxhm'];
    }

    if ($_POST['ar_kykloforias'] !== "") {
        $w = $w . " and ar_kykloforias LIKE ? ";
        $a[$i++] ="%" . $_POST['ar_kykloforias']. "%" ;
    }

    ?>
    <div><table class="table table-bordered table-hover table-responsive" style="width: available;background-color: cyan">

            <thead>
                <tr style="background-color: darkcyan">

                    <th>Κωδικός Οχήματος</th>
                    <th>Μάρκα Οχήματος</th>
                    <th>Μοντέλο Οχήματος</th>
                    <th>Αριθμός Κυκλοφορίας</th> 
                    <th>Λειτουργίες</th> 
                </tr>
            </thead>
            <tbody>
                <tr>
                    <?php
                    $res = $DB->execute($sql . $w, $a);
                    
                    //-------------Μέτρηση αποτελεσμάτων εγγραφών---------//

                    if ($res->rowCount() == 1) {

                        echo "<h4>Βρέθηκε " . $res->rowCount() . " εγγραφή με τα κριτήρια που δώσατε! </h4>";
                    } else if ($res->rowCount() == 0) {

                        echo "<h4>Δεν βρέθηκαν εγγραφές με τα κριτήρια που δώσατε! </h4>";
                    } else {
                        echo "<h4>Βρέθηκαν " . $res->rowCount() . " εγγραφές με τα κριτήρια που δώσατε! </h4>";
                    }

                    while ($row = $res->fetch()) {

                        $OxhmaSearch = new Oxhma();
                        $OxhmaSearch->ar_kykloforias = $row['ar_kykloforias'];
                        $OxhmaSearch->getDb();
                        
                        
                       
                       
                        echo "<td>" . $OxhmaSearch->odhgos . "</td>";
                        echo "<td>" . $OxhmaSearch->marka_oxhm . "</td>";
                        echo "<td>" . $OxhmaSearch->montelo_oxhm . "</td>";
                        echo "<td>" . $OxhmaSearch->ar_kykloforias . "</td>";
                        ?>

                        <td class="">
                            <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Ohimata/ViewOxhma.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="viewoxhmaid" value="<?php echo $OxhmaSearch->odhgos; ?>" readonly>
                            <button type="submit" title="Προβολή Οχήματος" style="width:120px; height:40px; background-color:blue;" class="btn-large">
                                <i>Προβολή Οχήματος</i></button>
                        </form>
                            
                            <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Ohimata/EditOxhma.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="editoxhmaid" value="<?php echo $OxhmaSearch->odhgos; ?>" readonly>
                            <button type="submit" title="Επεξεργασία Έργου" style="width:120px; height:40px; background-color:greenyellow;" class="btn-large">
                                <i>Επεξεργασία Οχήματος</i></button>
                        </form>
                            
                            
                            
                            
                            
                        <?php
                        if ($_SESSION['user_type_ergazom']==1) { ?>
                            <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Ohimata/DeleteOxhma.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="deloxhmaid" value="<?php echo $OxhmaSearch->odhgos;?>" readonly>
                            <button type="submit" title="Διαγραφή Οχήματος" style="width:120px; height:40px; background-color:red;" class="btn-large">
                                <i>Διαγραφή Οχήματος</i></button>
                        </form> <?php } ?>

                    </td>

                        <?php
                        echo "</tr>";
                    }
                    ?>

                    <?php
                    echo "</tbody></table></div>";
                }



