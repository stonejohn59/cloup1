<?php
session_start();
  require_once '../../Classes/Oxhma.php';
  require_once '../../Classes/Database.php';
 
$Oxhma= new Oxhma();
$Oxhma->ar_kykloforias=$_POST['deloxhmaid'];


if (!isset($_POST['delbutton'])){
    
    echo 'Είστε σίγουρος για την διαγραφή';
    $delcode=$Oxhma->odhgos;
    ?>
<form action="" method="post">
    <input type="hidden" name="delcode" value="<?php echo $delcode; ?>" >
<button style="float: left" type="submit" name="delbutton" id="delbutton" onclick="return confirm('Επιβεβαιώστε την διαγραφή')" value="Διαγραφή" class="btn btn-info "><span class="glyphicon glyphicon-trash"></span> Διαγραφή Οχήματος</button>
</form>     
    
<?php
}

else { //Σου πατάω το κουμπί επιβεβαίωσης οπότε διέγραψέ το.
$delcode=$_POST['delcode'];
$DB=new Database();
$DB->connect();
$sql = "DELETE FROM `oxhma` WHERE `odhgos`= ?";
        $DB->execute($sql, [$delcode]);
        echo 'Επιτυχής Διαγραφή';
}