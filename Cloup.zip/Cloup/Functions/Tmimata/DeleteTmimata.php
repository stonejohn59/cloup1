<?php
session_start();
  require_once '../../Classes/Tmhma.php';
  require_once '../../Classes/Database.php';
 
$tmhma= new Tmhma();
$Tmhma->kwd_tmhmatos=$_POST['deltmhmaid'];


if (!isset($_POST['delbutton'])){
    
    echo 'Είστε σίγουρος για την διαγραφή';
    $delcode=$Tmhma->kwd_tmhmatos;
    ?>
<form action="" method="post">
    <input type="hidden" name="delcode" value="<?php echo $delcode; ?>" >
<button style="float: left" type="submit" name="delbutton" id="delbutton" onclick="return confirm('Επιβεβαιώστε την διαγραφή')" value="Διαγραφή" class="btn btn-info "><span class="glyphicon glyphicon-trash"></span> Διαγραφή Τμήματος</button>
</form>     
    
<?php
}

else { //Σου πατάω το κουμπί επιβεβαίωσης οπότε διέγραψέ το.
$delcode=$_POST['delcode'];
$DB=new Database();
$DB->connect();
$sql = "DELETE FROM `tmhma` WHERE `kwd_tmhmatos`= ?";
        $DB->execute($sql, [$delcode]);
        echo 'Επιτυχής Διαγραφή';
}