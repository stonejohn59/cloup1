<?php
session_start();

require_once '../../Classes/Tmhma.php';
require_once '../../Classes/Database.php';


if (!isset($_POST['search'])) { ?>

<h1 class="form-header">Αναζήτηση Τμήματος</h1> 
    <form action="" method="post"> 
        <div class="form-group">
                <label for="kwd_tmhmatos">Κωδικός Τμήματος </label>
                <input type="text" id="odhgos" name="kwd_tmhmatos" class="form-control">
            </div>  
            <div class="form-group">
                <label for="onoma_tmhmatos">Όνομα Τμήματος</label>
                <input type="text" id="onoma_tmhmatos" name="onoma_tmhmatos" class="form-control">
            </div>  
        <div class="form-group">
                <label for="kwd_proistamenou">Κωδικός Προιστάμενου </label>
                <input type="text" id="kwd_proistamenou" name="kwd_proistamenou" class="form-control">
            </div> 
        
        
        
            <div class="clear-float"></div>
            <button style="float: left" type="submit" name="search" id="search" value="Αναζήτηση" class="btn btn-info "><span class="fa-search "></span> Αναζήτηση Τμήματος</button>
            <button style="float: left;color: #ff6666" type="button" name="cancel" id="cancel" value="Ακύρωση" onclick="window.location = 'ιndex.php';" class="btn btn-info "><span class="fa-backward"></span> Ακύρωση</button>
            <br><br>
        </form>
    
 <?php   
}
else {

    echo "<h3>Τμήμα:</h3>";
    $DB = new Database();
    $DB->connect();
    $sql ="SELECT `kwd_tmhmatos`, `onoma_tmhmatos`, `kwd_proistamenou` FROM `Tmhma`";
    $w = "where ?";

    $i = 0;
    $a = [];
    $a[$i++] = "1";


   if ($_POST['kwd_tmhmatos'] !== "") {
        $w = $w . " and kwd_tmhmatos = ? ";
        $a[$i++] = $_POST['kwd_tmhmatos'];
    }

    if ($_POST['onoma_tmhmatos'] !== "") {
        $w = $w . " and onoma_tmhmatos LIKE ? ";
        $a[$i++] ="%" . $_POST['onoma_tmhmatos']. "%" ;
    }
   
    if ($_POST['kwd_proistamenou'] !== "") {
        $w = $w . " and kwd_proistamenou = ? ";
        $a[$i++] = $_POST['kwd_proistamenou'];
    }


    ?>
    <div><table class="table table-bordered table-hover table-responsive" style="width: available;background-color: cyan">

            <thead>
                <tr style="background-color: darkcyan">

                    <th>Κωδικός Τμήματος</th>
                    <th>Όνομα Τμήματος</th>
                    <th>Κωδικός Προιστάμενου</th>
                    <th>Λειτουργίες</th> 
                </tr>
            </thead>
            <tbody>
                <tr>
                    <?php
                    $res = $DB->execute($sql . $w, $a);
                    
                    //-------------Μέτρηση αποτελεσμάτων εγγραφών---------//

                    if ($res->rowCount() == 1) {

                        echo "<h4>Βρέθηκε " . $res->rowCount() . " εγγραφή με τα κριτήρια που δώσατε! </h4>";
                    } else if ($res->rowCount() == 0) {

                        echo "<h4>Δεν βρέθηκαν εγγραφές με τα κριτήρια που δώσατε! </h4>";
                    } else {
                        echo "<h4>Βρέθηκαν " . $res->rowCount() . " εγγραφές με τα κριτήρια που δώσατε! </h4>";
                    }

                    while ($row = $res->fetch()) {

                        $TmhmaSearch = new Tmhma();
                        $TmhmaSearch->kwd_tmhmatos = $row['kwd_tmhmatos'];
                        $TmhmaSearch->getDb();
                        
                        
                       
                       
                        echo "<td>" . $TmhmaSearch->kwd_tmhmatos . "</td>";
                        echo "<td>" . $TmhmaSearch->onoma_tmhmatos . "</td>";
                        echo "<td>" . $TmhmaSearch->kwd_proistamenou . "</td>";
                        ?>

                        <td class="">
                            <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Tmimata/ViewTmimata.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="viewtmimaid" value="<?php echo $TmhmaSearch->kwd_tmhmatos; ?>" readonly>
                            <button type="submit" title="Προβολή Τμήματος" style="width:120px; height:40px; background-color:blue;" class="btn-large">
                                <i>Προβολή Τμήματος</i></button>
                        </form>
                            
                            <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Tmimata/EditTmimata.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="viewtmimaid" value="<?php echo $TmhmaSearch->kwd_tmhmatos; ?>" readonly>
                            <button type="submit" title="Επεξεργασία Τμήματος" style="width:120px; height:40px; background-color:greenyellow;" class="btn-large">
                                <i>Επεξεργασία Τμήματος</i></button>
                        </form>
                            
                            
                            
                            
                            
                        <?php
                        if ($_SESSION['kwd_tmhmatos']==1) { ?>
                            <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Tmimata/DeleteTmimata.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="deltmimaid" value="<?php echo $TmhmaSearch->kwd_tmhmatos;?>" readonly>
                            <button type="submit" title="Διαγραφή Τμήματος" style="width:120px; height:40px; background-color:red;" class="btn-large">
                                <i>Διαγραφή Τμήματος</i></button>
                        </form> <?php } ?>

                    </td>

                        <?php
                        echo "</tr>";
                    }
                    ?>

                    <?php
                    echo "</tbody></table></div>";
                }




