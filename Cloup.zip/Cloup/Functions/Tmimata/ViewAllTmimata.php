<h2>Προβολή όλων των Τμημάτων</h2>
<?php
session_start();
  require_once '../../Classes/Tmhma.php';
  require_once '../../Classes/Database.php';
?>

<div><table class="table table-responsive table-bordered table-condensed"
            style="
            border-radius: 10px;
            padding-top: 5px;
            padding-left: 5px;
            padding-right: 5px;
            padding-bottom: 5px;
            max-width: available;
            margin: 0px;
            background-color: whitesmoke;
            ">
        <thead>
            <tr style="background-color:   #6699ff">

                <th style=white-space:nowrap">Κωδικός Τμήματος</th>
                <th>Όνομα Τμηματος</th>
                <th>Κωδικός Προιστάμενου</th>
                
              
                <th style="width: 250px">Λειτουργίες</th>

            </tr>
        </thead>
        <tbody>
            <tr style="">
                <?php
                $DB = new Database();
                $DB->connect();
                $res = $DB->execute("SELECT `kwd_tmhmatos`, `onoma_tmhmatos`, `kwd_proistamenou`,  FROM `tmhma` where kwd_tmhmatos !=0 ", []);
                while ($row = $res->fetch()) {
                    echo "<td>" . $row['kwd_tmhmatos'] . "</td>";
                    echo "<td>" . $row['onoma_tmhmatos'] . "</td>";
                    echo "<td>" . $row['kwd_proistamenou'] . "</td>";
                    
                    
                    ?>
                    <td class="">
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Tmimata/ViewTmimata.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="viewtmimaid" value="<?php echo $row['kwd_tmhmatos']; ?>" readonly>
                            <button type="submit" title="Προβολή Τμήματος" style="width:120px; height:20px; background-color:blue;" class="btn-large">
                                <i>Προβολή Τμήματος </i></button>
                        </form>
                        
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Tmimata/DeleteTmimata.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="deltmimaid" value="<?php echo $row['kwd_tmhmatos'];?>" readonly>
                            <button type="submit" title="Διαγραφή Τμήματος" style="width:120px; height:20px; background-color:red;" class="btn-large">
                                <i>Διαγραφή Τμήματος</i></button>
                        </form>
                        
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Ohimata/EditOxhma.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="edittmimaid" value="<?php echo $row['kwd_tmhmatos'];?>" readonly>
                            <button type="submit" title="Τροποποίηση Τμήματος" style="width:120px; height:20px; background-color:green;" class="btn-large">
                                <i>Τροποποίηση Τμήματος</i></button>
                        </form>

                    </td>

                    <?php
                    echo "</tr>";
                }//Τέλος εκτύπωσης γραμμής
                ?>
                <?php
                echo "</tbody></table></div>";
