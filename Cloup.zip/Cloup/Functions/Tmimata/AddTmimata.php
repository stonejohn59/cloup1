<?php
require_once '../../Classes/Tmhma.php';
require_once '../../Classes/Database.php';


if (!isset($_POST['AddTmima'])) { ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Τμήματα</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../../css/newcss.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  
</head>
<body>
    <h1 class="form-header">ΠΡΟΣΘΗΚΗ ΝΕΟΥ TMHMATOS </h1>
    <form action="" method="post">     
            <div class="form-group">
                <label for="kwd_tmhmatos">Κωδικός Τμήματος </label>
                <input type="text" id="markaOxim" name="kwd_tmhmatos" required class="form-control">
            </div>  
        <div class="form-group">
                <label for="onoma_tmhmatos">Όνομα Τμήματος </label>
                <input type="text" id="onoma_tmhmatos" name="onoma_tmhmatos" required class="form-control">
            </div> 
        <div class="form-group">
                <label for="kwd_proistamenou">Κωδικός Προιστάμενου</label>
                <input type="text" id="kwd_proistamenou" name="kwd_proistamenou" required class="form-control">
            </div>  
        
         
        <div class="clear-float"></div>
      
            <button style="float: left; text-align: center" type="submit" name="AddTmima" id="AddVehicle" value="Προσθήκη" class="btn btn-info "><span class="glyphicon glyphicon-plus-sign"></span> Καταχώρηση Τμήματος</button>
            <button style="float: left; color: #ff6666" type="button" name="cancel" id="cancel" value="Ακύρωση" onclick="window.location = 'ιndex.php';" class="btn btn-info "><span class="glyphicon glyphicon-remove-sign"></span> Ακύρωση</button>
            <br><br>
        </form>
    </div>
    
</body> 
   
    
<?php 

                    }
                    else { //Μόλις πατήσω το κουμπί Προσθήκη Τμήματος (Στα Post )
                       
                        $tmima = new Tmhma();
                        $tmima->kwd_tmhmatos = $_POST['kwd_tmhmatos'];
                        $tmima->onoma_tmhmatos = $_POST['onoma_tmhmatos'];
                        $tmima->kwd_proistamenou = $_POST['kwd_proistamenou'];
                        $tmima->setDb();
                    }
?>


