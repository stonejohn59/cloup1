<?php


session_start();

require_once '../../Classes/Tmimata.php';
require_once '../../Classes/Database.php';

if ((isset($_POST['edittmimaid'])) && (!isset($_POST['edittmima2']))) {
    $edittmima=new Tmhma();
    $edittmima->odhgos=$_POST['editoxhmaid'];
    $edittmima->getDb();
    
    ?>
    <form action="" method="post">
        <div id="SearchPart" class="col-lg-4">
            <h3>Επεξεργασία Στοιχείων Τμήματος</h3>
            <input type="text" name="paliosTmimaCode" value="<?php echo $_POST['edittmimaid']; ?>" >


            <div class="form-group">
                <label for="edittmima2">Κωδικός Τμήματος</label>
                <input type="text" id="edittmima2" name="edittmima2" value="<?php echo $_POST['edittmimaid']; ?>" required class="form-control">
            </div>  
            <div class="form-group">
                <label for="onoma_tmhmatos">Όνομα Τμήματος</label>
                <input type="text" id="onoma_tmhmatos" name="onoma_tmhmatos" value="<?php echo $edittmima->onoma_tmhmatos; ?>"  class="form-control" required>
            </div>
            <div class="form-group">
                <label for="kwd_proistamenou">Κωδικός Προιστάμενου</label>
                <input type="text" id="kwd_proistamenou" name="kwd_proistamenou" value="<?php echo $edittmima->kwd_proistamenou; ?>"  class="form-control" required>
            </div>
            

            <button style="float: left" type="submit" name="EditTmima" id="EditTmima" value="Ενημέρωση" class="btn btn-info "><span class="glyphicon glyphicon-retweet"></span> Ενημέρωση Τμήματος</button>
            <button style="float: left ; color: #ff6666" type="button" name="cancel" id="cancel" value="Ακύρωση" onclick="window.location = 'Index.php';" class="btn btn-info "><span class="glyphicon glyphicon-remove-sign"></span> Ακύρωση</button>

    </form>
    </div>

    <?php
} else {
    
    $edittmimafinal= new Tmhma();
    $edittmimafinal->kwd_tmhmatos=$_POST['edittmima2'];
    $edittmimafinal->onoma_tmhmatos=$_POST['onoma_tmhmatos'];
    $edittmimafinal->kwd_proistamenou=$_POST['kwd_proistamenou'];
    $edittmimafinal->updateDb();
    
}