<?php
session_start();
require_once '../../Classes/Epimorfosi.php';
require_once '../../Classes/Database.php';
require_once '../../Classes/Ergazomenos.php';
require_once '../../Classes/Ekpaideush.php';

$epimorfosi= new Epimorfosi();
$epimorfosi->ekpaideyomenos=$_POST['viewepimorfid'];
$epimorfosi->getDb();

$ekpaideush=new Ekpaideysh();
$ekpaideush->kwd_ergazomenou=$epimorfosi->ekpaideyomenos;
$ergaz->getDB();


echo "Κωδικός Εκπαιδευόμενου:".$epimorfosi->ekpaideyomenos;
echo '</br>';
echo "Επώνυμο:".$ergaz->Eponymo_ergazom;
echo '</br>';
echo "Όνομα".$ergaz->$Onoma_Ergazom;
echo '</br>';
echo "Κωδικός Ειδίκευσης:".$epimorfosi->eidikeysh;
echo '</br>';
echo "Τίτλος Πτυχίου:".$ekpaideush->per_ptuxiou;
echo '</br>';
echo "Βαθμός:".$ekpaideush->vathmos;
echo '</br>';
echo "Ημ/νία Αποφοίτησης:".$ekpaideush->date_apokthshs;








