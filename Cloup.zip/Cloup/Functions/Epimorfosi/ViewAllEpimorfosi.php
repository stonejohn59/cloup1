<h2>Προβολή όλων των Επιμορφόσεων</h2>
<?php
session_start();
  require_once '../../Classes/Epimorfosi.php';
  require_once '../../Classes/Database.php';
  
?>

<div><table class="table table-responsive table-bordered table-condensed"
            style="
            border-radius: 10px;
            padding-top: 5px;
            padding-left: 5px;
            padding-right: 5px;
            padding-bottom: 5px;
            max-width: available;
            margin: 0px;
            background-color: whitesmoke;
            ">
        <thead>
            <tr style="background-color:   #6699ff">

                <th style=white-space:nowrap">Εκπαιδευόμενος</th>
                <th>Ειδίκευση</th>
                
                
              
                <th style="width: 250px">Λειτουργίες</th>

            </tr>
        </thead>
        <tbody>
            <tr style="">
                <?php
                $DB = new Database();
                $DB->connect();
                $res = $DB->execute("SELECT `ekpaideyomenos`, `eidikeysh`,  FROM `epimorfosi` where ekpaideyomenos !=1 ", []);
                while ($row = $res->fetch()) {
                    echo "<td>" . $row['ekpaideyomenos'] . "</td>";
                    echo "<td>" . $row['eidikeysh'] . "</td>";
                    
                    ?>
                    <td class="">
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Epimorfosi/ViewEpimorfosi.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="viewepimorid" value="<?php echo $row['$ekpaideyomenos']; ?>" readonly>
                            <button type="submit" title="Προβολή Εκπεδευόμενου" style="width:120px; height:20px; background-color:blue;" class="btn-large">
                                <i>Προβολή Εκπεδευόμενου</i></button>
                        </form>
                        
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Epimorfosi/DeleteEpimorfosi.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="delepimorid" value="<?php echo $row['$ekpaideyomenos'];?>" readonly>
                            <button type="submit" title="Διαγραφή " style="width:120px; height:20px; background-color:red;" class="btn-large">
                                <i>Διαγραφή </i></button>
                        </form>
                        <form style ="float: left; padding: 2px;" method="post" action="../../Functions/Epimorfosi/EditEpimorfosi.php" target="_blank">
                            <input style=" display:none ;color: red; width: 0px; height: 0px;" 
                                   type="text" name="editepimorid" value="<?php echo $row['$ekpaideyomenos'];?>" readonly>
                            <button type="submit" title="Τροποποίηση " style="width:120px; height:20px; background-color:green;" class="btn-large">
                                <i>Τροποποίηση </i></button>
                        </form>

                    </td>

                    <?php
                    echo "</tr>";
                }//Τέλος εκτύπωσης γραμμής
                ?>
                <?php
                echo "</tbody></table></div>";



                