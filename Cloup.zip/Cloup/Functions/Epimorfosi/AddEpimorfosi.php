<?php
    require_once '../../Classes/Epimorfosi.php';
    require_once '../../Classes/Database.php';
    require_once '../../Classes/Ergazomenos.php';
    
    
    
if (!isset($_POST['AddEpimorfosi'])) { ?>
    
    <form action="" method="post">     
            
        <div class="form-group">
                <label for="ekpaideyomenos">Εκπαιδευόμενος</label>
                <input type="text" id="ekpaideyomenos" name="ekpaideyomenos" required class="form-control">
            </div> 
        <div class="form-group">
                <label for="eidikeush">Ειδίκευση </label>
                <input type="text" id="eidikeush" name="eidikeush" class="form-control">
            </div>
        
        <button style="float: left" type="submit" name="AddEidikeush" id="AddErgo" value="Προσθήκη" class="btn btn-info "><span class="glyphicon glyphicon-plus-sign"></span> Καταχώρηση </button>
        <button style="float: left; color: #ff6666" type="button" name="cancel" id="cancel" value="Ακύρωση" onclick="window.location = 'ιndex.php';" class="btn btn-info "><span class="glyphicon glyphicon-remove-sign"></span> Ακύρωση</button>

        </form>
    </div>
        
<?php 

                    }
                    else { //Μόλις πατήσω το κουμπί Προσθήκη Ειδίκευσης (Στα Post )
                        $epimorfosi=new Epimorfosi();
                        
                        $epimorfosi->ekpaideyomenos=$_POST["ekpaideyomenos"];
                        $epimorfosi->eidikeysh=$_POST["eidikeysh"];
                        
                        $epimorfosi->setDb();
                    }
